# Checklist Manual de QA

- Guardar P1/P2 correctamente en Ajustes.
- Diagnóstico muestra la Outbound IP correcta y variables de red.
- “Probar conexión” devuelve HTTP 200 y JSON válido.
- El shortcode renderiza cards correctamente en desktop y móvil.
- Probar variantes de `filter_agency_id` (1,2,3,4), `per_page` y `page`.
- No aparecen notices ni warnings con `WP_DEBUG=true`.
